@echo off
cd /d "%~dp0"
start "" /wait Verbatim.exe --audio-test diagnostic-audio.txt
start "" notepad diagnostic-audio.txt
